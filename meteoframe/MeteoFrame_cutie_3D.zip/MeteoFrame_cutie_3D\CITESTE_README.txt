﻿MeteoFrame - cutie pentru imprimanta 3D / 3D-printed case
Placa / Board: Waveshare ESP32-S3-Touch-LCD-7 (800x480)

RO
- cutie_spate.stl     : cutia din spate (se prinde cu 4 suruburi M3 in piulitele de pe spatele placii)
- suport_inclinat.stl : suportul de masa, inclinat la 15 grade
- Decupaj in spate pentru cablul USB-C, fante de aerisire.
- PLA / PETG, fara suporturi: cutia cu spatele pe masa, suportul culcat pe o parte.

EN
- cutie_spate.stl     : the back case (4 M3 screws into the nuts on the back of the board)
- suport_inclinat.stl : the desk stand, tilted 15 degrees
- Cut-out at the back for the USB-C cable, ventilation slots.
- PLA / PETG, no supports: the case with its back on the bed, the stand lying on its side.

(c) 2026 YO2CR - yo2cr.ro - gratuit / free

